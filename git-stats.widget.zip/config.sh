#!/bin/sh

# Configuration

repoPath="/path/to/your/repo"
